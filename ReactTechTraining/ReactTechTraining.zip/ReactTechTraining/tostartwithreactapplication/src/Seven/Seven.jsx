import React from 'react';
import './Seven.css'

const Seven =() => {
    return <div>
    <h1 style={{color: "red"}} >Welcome again here</h1> 
    <h2> Welcome again here TWice  </h2>
    </div>
}

export default Seven;


// 1. adding simple inline styles
// 2. adding styles simply using index.js 