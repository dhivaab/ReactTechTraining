import logo from './logo.svg';
import './App.css';
import ExportOne from './One';
import OneAgain from './One';
import Two from './Two';
import Three from './Three';
import Four from './Four';
import Five from './Five';
import Six from './Six';
import Seven from './Seven/Seven';
import Eight from './Eight/Eight';
import Nine from './Nine';
import Ten from './Ten';
import Eleven from './Eleven';
import Twelve from './Twelve';
import Thirteen from './Thirteen';

function App() {
  return (
    <div className="App">
      {/* <ExportOne/> */}
    
    {/* <Two/> */}

    {/* <Three/> */}
    {/* <Four/> */}


    {/* {<Five/>} */}

    {/* {<Six/>} */}

    {/* <Seven/>*/}

    {/* <Eight/> */}

    {/* <Nine favcol ="yellow"/> */}

    {/* <Ten favcol ="orange"/> */}

    {/* <Eleven/> */}

    {/* <Twelve/> */}

    {/* <Thirteen/> */}
    </div>
  );
}

export default App;
