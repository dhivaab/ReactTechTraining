export let todos = [
    {
        id: 1,
        name: "One"
    },
    {
        id: 2,
        name: "Two"
    },
    {
        id:3,
        name: "Three"
    }
]