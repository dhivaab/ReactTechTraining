import './App.css';
import UserComponent from './users/users';

function App() {
  return (
    <div className="App"> 
    <UserComponent></UserComponent>
    </div>
  );
}

export default App;
