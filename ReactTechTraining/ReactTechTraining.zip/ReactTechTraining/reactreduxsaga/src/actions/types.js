export const Types = {
    GET_USERS_REQUEST: 'get_users_request',
    GET_USERS_SUCCESS: 'get_users_success'
}