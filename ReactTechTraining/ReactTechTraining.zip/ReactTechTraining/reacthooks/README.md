# One.jsx -> use state hook 
# Two.jsx -> More in Use state
# Three.jsx -> useEffect
# Four.jsx -> React Context 
# Five.jsx -> React Hooks useEffect - Effectively for lifecycle 