import React  from 'react';
import { Student } from './Student';

export const Teacher =() => {
    return (
        <Student/>

    )
}