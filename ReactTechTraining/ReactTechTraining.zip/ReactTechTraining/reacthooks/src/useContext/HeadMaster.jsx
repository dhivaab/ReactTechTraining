import React from 'react';
import { Teacher } from "./Teacher";


export const HeadMaster =() => {
    return (
            <Teacher/>
    );
}
