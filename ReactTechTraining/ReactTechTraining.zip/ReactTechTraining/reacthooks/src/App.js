import logo from './logo.svg';
import './App.css';
import One from './One';
import Two from './Two';
import Three from './Three';
import Four from './Four';
import Five from './Five';

function App() {
  return (
    <div className="App">
      {/* <One/> */}
      {/* <Two/> */}
      {/* <Three/> */}

      {/* <Four/> */}
      <Five/>
    </div>
  );
}

export default App;
